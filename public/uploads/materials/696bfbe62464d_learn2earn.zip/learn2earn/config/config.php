<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'learn2earn');

// The Query String Routing URL [cite: 1816]
define('BASE_URL', 'http://localhost/learn2earn/');

// CRITICAL: This must be at the very top of the config
session_start();