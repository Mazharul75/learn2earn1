<!DOCTYPE html>
<html>
<head>
    <title>Learn2Earn</title>
    <link rel="stylesheet" type="text/css" href="<?= BASE_URL ?>public/css/style.css">
</head>
<body>
<nav>
    <a href="<?= BASE_URL ?>dashboard/index">Dashboard</a> | 
    <a href="<?= BASE_URL ?>auth/profile">My Profile</a> | 
    <a href="<?= BASE_URL ?>auth/logout">Logout</a>
</nav>
<hr>